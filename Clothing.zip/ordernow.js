
    $(document).ready(function () {
        
      getData();
        const townships = {
  yangon: ["Mayangone", "Thaketa", "Hlaing", "Kyauktada", "North Dagon"],
  mandalay: ["Chan Aye Thar Zan", "Amarapura", "Pyigyidagun", "Mahaaungmyay"],
  naypyidaw: ["Zabuthiri", "Ottarathiri", "Pobbathiri", "Dekkhina Thiri"],

  // 7 Regions
  ayeyarwady: ["Pathein", "Hinthada", "Myaungmya", "Maubin", "Pyapon"],
  bago: ["Bago", "Taungoo", "Pyay", "Tharrawaddy"],
  magway: ["Magway", "Minbu", "Pakokku", "Yenangyaung"],
  mandalay_region: ["Mandalay", "Pyin Oo Lwin", "Myingyan", "Meiktila"],
  sagaing: ["Sagaing", "Shwebo", "Monywa", "Kale"],
  tanintharyi: ["Dawei", "Myeik", "Kawthaung"],
  yangon_region: ["Mayangone", "Thanlyin", "South Dagon", "Thingangyun"],

  // 7 States
  chin: ["Hakha", "Falam", "Thantlang", "Tedim"],
  kachin: ["Myitkyina", "Bhamo", "Putao", "Mogaung"],
  kayah: ["Loikaw", "Demoso", "Bawlakhe"],
  kayin: ["Hpa-An", "Myawaddy", "Hlaingbwe", "Kawkareik"],
  mon: ["Mawlamyine", "Thaton", "Ye", "Paung"],
  rakhine: ["Sittwe", "Kyaukpyu", "Thandwe", "Mrauk-U"],
  shan: ["Taunggyi", "Lashio", "Kengtung", "Muse", "Kalaw"]
};



      $('#region').change(function () {
        const selectedRegion = $(this).val();
        const $township = $('#township');
        $township.empty(); // remove all existing options

        $township.append('<option value="">-- Select Township --</option>');

        if (townships[selectedRegion]) {
          townships[selectedRegion].forEach(function (township) {
            $township.append(`<option value="${township.toLowerCase()}">${township}</option>`);
          });
        }
      });
      getData();
      function getData(){
        let customerString=localStorage.getItem('customers');
        let customerArray=JSON.parse(customerString);

        let data='';
        let j=1;
        $.each(customerArray,function(i,v){
            console.log(v);
            console.log(v.name);
            let name=v.name;
            let phone=v.phone;
            let region=v.region;
            let township=v.township;
            let address=v.address;
            data+=`<tr>
                <td>${j++}</td>
                 <td>${name}</td>
                  <td>${phone}</td>
                   <td>${region}</td>
                    <td>${township}</td>
                     <td>${address}</td>
                </tr>`
        })
        $('tbody').html(data);
      }
    
      $('#add').click(function(){
        let name =$("#name").val();
        let phone=$("#phone").val();
        let region=$('#region').val();
        let township=$('#township').val();
        let address=$('#address').val();

        let customers={name:name,
          phone:phone,region:region,township:township,address:address
        }
        console.log(customers);
     
      let customerString=localStorage.getItem('customers');
      let customerArray;
      if(customerString==null){
        customerArray=[];

      }else{
        customerArray=JSON.parse(customerString);

      }
      customerArray.push(customers);
      console.log(customerArray);
      let customerData=JSON.stringify(customerArray);
      console.log(customerData);
      localStorage.setItem('customers',customerData);
      getData();
      $('#name').val('');
        $('#phone').val('');
        $('#region').val('');
        $('#township').val('');
        $('#address').val('');
        // $('#amount').val('');
        window.location.href="clothing.html";
    });
   

})
